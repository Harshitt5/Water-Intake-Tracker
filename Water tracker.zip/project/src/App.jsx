import { useState, useEffect } from 'react';
import confetti from 'canvas-confetti';

export default function App() {
  const CUP_SIZE = 250; // ml
  const GOAL = 2000; // ml
  const TOTAL_CUPS = GOAL / CUP_SIZE;

  const [cupsFilled, setCupsFilled] = useState(0);
  const [breathPhase, setBreathPhase] = useState('Inhale');

  useEffect(() => {
    const interval = setInterval(() => {
      setBreathPhase((prev) => (prev === 'Inhale' ? 'Exhale' : 'Inhale'));
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  const handleCupClick = (index) => {
    const newCupsFilled = index + 1 === cupsFilled ? index : index + 1;
    setCupsFilled(newCupsFilled);
    
    // Trigger confetti when goal is reached
    if (newCupsFilled === TOTAL_CUPS) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
    }
  };

  const addCup = () => {
    if (cupsFilled < TOTAL_CUPS) {
      const newCupsFilled = cupsFilled + 1;
      setCupsFilled(newCupsFilled);
      
      // Trigger confetti when goal is reached
      if (newCupsFilled === TOTAL_CUPS) {
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 }
        });
      }
    }
  };

  const resetCups = () => setCupsFilled(0);

  const progressPercent = (cupsFilled / TOTAL_CUPS) * 100;

  return (
    <div className="p-6 max-w-xl mx-auto text-center">
      <h1 className="text-2xl font-bold mb-6">💧 Water & Breathing Tracker</h1>

      {/* Water Tracker */}
      <div className="mb-10">
        <h2 className="text-xl font-semibold mb-2">Water Intake</h2>

        <div className="flex flex-wrap justify-center gap-2 mb-2">
          {[...Array(TOTAL_CUPS)].map((_, i) => (
            <button
              key={i}
              className={`w-12 h-12 rounded-full border-2 transition ${
                i < cupsFilled ? 'bg-blue-400 border-blue-600' : 'border-gray-300'
              }`}
              onClick={() => handleCupClick(i)}
              title={`${(i + 1) * CUP_SIZE}ml`}
            />
          ))}
        </div>

        {/* Water Progress Bar */}
        <div className="h-4 bg-gray-200 rounded-full overflow-hidden mt-4">
          <div
            className="h-full transition-all duration-500"
            style={{
              width: `${progressPercent}%`,
              background: 'linear-gradient(90deg, #60A5FA, #3B82F6)'
            }}
          ></div>
        </div>

        <p className="text-sm text-gray-600 mt-2">
          {cupsFilled * CUP_SIZE}ml / {GOAL}ml
        </p>

        <div className="mt-2 flex gap-4 justify-center">
          <button
            className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600 text-sm"
            onClick={addCup}
          >
            ➕ Add Cup
          </button>
          <button
            className="text-red-500 underline hover:text-red-700 text-sm"
            onClick={resetCups}
          >
            Reset
          </button>
        </div>
      </div>

      {/* Breathing Animation */}
      <div className="text-center mt-8">
        <h2 className="text-xl font-semibold mb-2">Breathing Exercise</h2>
        <div className="relative w-40 h-40 mx-auto">
          <div
            className={`w-full h-full rounded-full bg-green-300 transition-all duration-1000 ${
              breathPhase === 'Inhale' ? 'scale-110' : 'scale-90'
            }`}
          />
        </div>
        <p className="mt-4 text-lg font-medium">{breathPhase}</p>
      </div>
    </div>
  );
}